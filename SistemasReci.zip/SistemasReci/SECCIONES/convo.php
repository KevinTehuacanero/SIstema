<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<h2>Proyectos</h2>
                    <ul>
                        <!-- Aquí se mostrarían los proyectos dinámicamente desde la base de datos -->
                        <li><a href="proyecto.php?id=1">Convocatoria 2024-1</a></li>
                        <li><a href="proyecto.php?id=2">Convocatoria 2024-2</a></li>
                        <!-- ... -->
                    </ul>
</body>
</html>