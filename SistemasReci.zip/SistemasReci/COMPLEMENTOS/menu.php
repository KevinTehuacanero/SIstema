<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
      <!-- Menú lateral -->
      <nav id="sidebar">
            <div class="sidebar-header">
                <h3>Gestión de Proyectos</h3>
            </div>

            <ul class="list-unstyled components">
            <li class="active"><a href="#"><i class="fa fa-list-alt" aria-hidden="true"></i> PROYECTOS </a>
                <ul class="submenu">
                    <li><a href="SECCIONES/convo.php">Convocatoria</a></li>
                    <li><a href="proyectos.php">Proyectos</a></li>
                    
                </ul>
            </li>
            </ul>
            <ul class="list-unstyled components">
                <li class="active">
                    <a href="#registro de usuarios">Usuarios</a>
                </li>
            </ul>

            <ul class="list-unstyled components">
                <li class="active">
                    <a href="#registro de productividad">Productividad</a>
                </li>
            </ul>
        </nav>
        <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>

   <script>
    $(document).ready(function() {
        $(".active > a").on('click', function(e) {
            e.preventDefault();
            $(this).siblings(".submenu").slideToggle('fast');
        });

        $(".hide").on('click', function() {
            $("nav ul").toggle('slow');
        });
    });
</script>
</body>
</html>

