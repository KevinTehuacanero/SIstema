<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>Sistema Administrativo para la producion docente</title>
</head>
<body>

    <div class="wrapper">

      <?php include 'COMPLEMENTOS/menu.php' ?>

        <!-- Contenido principal -->
        <div id="content">

            <header>
                <h1>Sistema Administrativo para la producion docente</h1>
            </header>

            <main>
                <section id="proyectos">
                    
                </section>
            </main>

            <footer>
                <p>&copy;Sistema de Gestión de Proyectos</p>
            </footer>

        </div>

    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>

</body>
</html>
<style>
    body {
    font-family: 'Arial', sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f4f4f4;
}

header {
    background-color: #333;
    color: #fff;
    text-align: center;
    padding: 1em 0;
}

main {
    max-width: 800px;
    margin: 20px auto;
    padding: 20px;
}

section {
    background-color: #fff;
    padding: 20px;
    margin-bottom: 20px;
}

ul {
    list-style: none;
    padding: 0;
}

li {
    margin-bottom: 10px;
}

a {
    text-decoration: none;
    color: #007bff;
}

footer {
    background-color: #333;
    color: #fff;
    text-align: center;
    padding: 1em 0;
    position: fixed;
    width: 100%;
    bottom: 0;
}
/* Estilo del menú lateral */
#sidebar {
    min-width: 250px;
    max-width: 250px;
    height: 100%;
    background-color: #333;
    color: #fff;
    position: fixed;
    overflow-x: hidden;
    transition: all 0.3s;
}

#sidebar .sidebar-header {
    padding: 20px;
    text-align: center;
}

#sidebar ul.components {
    padding: 20px 0;
}

#sidebar ul li {
    padding: 10px;
    font-size: 1.2em;
    display: block;
}

#sidebar ul li a {
    color: #fff;
}

#sidebar ul li.active {
    background-color: #007bff;
}

#sidebar ul li.active a {
    color: #fff;
}

#content {
    margin-left: 250px;
    padding: 20px;
}



body {
    font-family: 'Arial', sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f4f4f4;
}

header {
    background-color: #333;
    color: #fff;
    text-align: center;
    padding: 1em 0;
}

main {
    max-width: 800px;
    margin: 20px auto;
    padding: 20px;
}



</style>